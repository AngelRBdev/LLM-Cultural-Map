#!/usr/bin/env python3
"""
B1 (Factual) generator — LLM Cultural Map benchmark.

Design (agreed with team):
- Yes/No comparative items. Each item names two countries and asks whether the
  person from country A is MORE likely than the person from country B to show a
  behaviour tied to ONE Meyer dimension.
- GOLD ANSWER IS DERIVED FROM DATA, not hand-written: it is computed from each
  country's position on Meyer's scale for that dimension. This makes every answer
  defensible ("Yes, because Meyer places A toward the low-context pole vs B").
- MIN_SEP: a pair is only used if the two countries are clearly separated on the
  dimension. This protects gold defensibility from small ordering errors.
- Same scenario template instantiated across MANY country pairs (the professor's
  A-vs-B / C-vs-D / E-vs-F idea). Consistency WITHIN a pair_group is the headline
  metric: a model that truly knows the *dimension* answers correctly across the
  famous AND the less-documented pairs; a model that memorised famous examples
  drops on the obscure pairs.
- ~35% of items are flagged counter-stereotype (two countries in the SAME macro
  region but on OPPOSITE sides of the dimension -> the naive "same region behaves
  alike" heuristic fails). The accuracy gap between stereotype-consistent and
  counter-stereotype items is itself evidence of shortcut learning.
- Order of A/B and which pole the question asks about are randomised so neither
  position nor a fixed "Yes" bias predicts the answer.

Two variants are produced for comparison:
  VARIANT A: 1 scenario template per dimension, many pairs.
  VARIANT B: 2 scenario templates per dimension, fewer pairs each.

Provenance note: Meyer's scale figures are not present as images in the supplied
text file, so positions below are Meyer's canonical published placements,
corroborated against the book text. Only well-separated pairs are emitted, so the
gold answers depend on clear relative placement, not exact ordinal rank.
"""

import json, random, itertools
from collections import defaultdict

random.seed(42)
MIN_SEP = 25          # minimum separation on the 0-100 scale for a pair to be valid
MID = 50             # scale midpoint, used for counter-stereotype detection
TOTAL = 96           # target items per variant (12 per dimension)
COUNTER_TARGET = 0.35

# ----------------------------------------------------------------------------
# GLOBE 10-cluster mapping (official GLOBE assignments)
# ----------------------------------------------------------------------------
CLUSTER = {
    "the United States":"Anglo","the United Kingdom":"Anglo","Australia":"Anglo","Canada":"Anglo",
    "Germany":"Germanic Europe","the Netherlands":"Germanic Europe","Switzerland":"Germanic Europe","Austria":"Germanic Europe",
    "Denmark":"Nordic Europe","Sweden":"Nordic Europe","Norway":"Nordic Europe","Finland":"Nordic Europe",
    "France":"Latin Europe","Italy":"Latin Europe","Spain":"Latin Europe","Israel":"Latin Europe",
    "Russia":"Eastern Europe","Poland":"Eastern Europe",
    "Brazil":"Latin America","Mexico":"Latin America","Argentina":"Latin America","Peru":"Latin America",
    "Saudi Arabia":"Middle East","Iran":"Southern Asia",  # GLOBE puts Iran in Southern Asia
    "Nigeria":"Sub-Saharan Africa","Ghana":"Sub-Saharan Africa","Kenya":"Sub-Saharan Africa",
    "India":"Southern Asia","Indonesia":"Southern Asia","Thailand":"Southern Asia",
    "China":"Confucian Asia","Japan":"Confucian Asia","South Korea":"Confucian Asia","Singapore":"Confucian Asia",
    # --- expansion countries (relieve thin clusters; see EXPANSION below) ---
    "the United Arab Emirates":"Middle East","Qatar":"Middle East","Kuwait":"Middle East","Egypt":"Middle East",
    "Zimbabwe":"Sub-Saharan Africa","Tanzania":"Sub-Saharan Africa",
}

# EXPANSION countries are NOT used as blanket cluster stand-ins. They are placed
# only on dimensions where the relevant bloc is genuinely homogeneous in the
# cross-cultural literature (the Arab Gulf is a tight bloc on Meyer's dimensions;
# Southern/Eastern African cultures sit consistently on the relationship /
# high-context / flexible / hierarchical / indirect ends). The code restricts
# them to CLEAR cross-region, opposite-pole, stereotype-CONSISTENT comparisons,
# and NEVER lets them appear in counter-stereotype items (where intra-cluster
# nuance is the whole point and imputation would be unsafe).
EXPANSION = {"the United Arab Emirates","Qatar","Kuwait","Egypt","Zimbabwe","Tanzania"}

# Macro regions, used ONLY for the counter-stereotype heuristic
def macro(country):
    c = CLUSTER[country]
    if c in ("Anglo","Germanic Europe","Nordic Europe","Latin Europe","Eastern Europe"): return "WEST"
    if c in ("Confucian Asia","Southern Asia"): return "ASIA"
    if c == "Latin America": return "LATAM"
    if c == "Sub-Saharan Africa": return "AFRICA"
    if c == "Middle East": return "MENA"

# ----------------------------------------------------------------------------
# Meyer scales: position 0 = far LOW pole, 100 = far HIGH pole.
# ----------------------------------------------------------------------------
SCALES = {
 "Communicating": {  # low = low-context (explicit)  ->  high = high-context (implicit)
   "the United States":5,"Australia":8,"Canada":12,"the Netherlands":15,"Germany":18,"Denmark":20,
   "the United Kingdom":28,"Poland":35,"Italy":50,"Spain":52,"Argentina":57,"Brazil":55,"France":58,
   "Mexico":60,"India":70,"Singapore":72,"Kenya":73,"Saudi Arabia":80,"Iran":82,"China":85,
   "South Korea":88,"Indonesia":90,"Japan":95,"Ghana":72,"Nigeria":76,
   "the United Arab Emirates":80,"Qatar":81,"Kuwait":79,"Egypt":77,"Zimbabwe":74,"Tanzania":75},
 "Evaluating": {  # low = direct negative feedback -> high = indirect
   "the Netherlands":5,"Germany":8,"Denmark":10,"Russia":12,"Israel":14,"France":25,"Spain":35,
   "Italy":40,"Australia":45,"the United States":50,"Canada":55,"the United Kingdom":58,"Brazil":60,
   "Argentina":62,"Mexico":68,"India":72,"Saudi Arabia":75,"Kenya":78,"Ghana":80,"China":85,
   "Indonesia":88,"Japan":92,"Thailand":95,"Nigeria":79,
   "the United Arab Emirates":76,"Qatar":75,"Kuwait":76,"Egypt":73,"Zimbabwe":79,"Tanzania":80},
 "Persuading": {  # low = applications-first -> high = principles-first (holistic Asian cultures off-scale)
   "the United States":5,"Canada":12,"Australia":15,"the United Kingdom":25,"the Netherlands":35,
   "Denmark":40,"Sweden":42,"Norway":43,"Germany":70,"Spain":75,"France":78,"Italy":80,"Russia":85},
 "Leading": {  # low = egalitarian -> high = hierarchical
   "Denmark":5,"Sweden":8,"Norway":10,"Finland":11,"the Netherlands":12,"Israel":14,"Australia":18,
   "Canada":22,"the United States":25,"the United Kingdom":30,"Germany":35,"France":55,"Spain":56,
   "Italy":58,"Brazil":60,"Mexico":65,"India":70,"Russia":72,"Saudi Arabia":78,"China":80,
   "Nigeria":82,"Indonesia":84,"South Korea":88,"Japan":90,"Ghana":78,"Kenya":76,
   "the United Arab Emirates":80,"Qatar":81,"Kuwait":78,"Egypt":76,"Zimbabwe":80,"Tanzania":79},
 "Deciding": {  # low = consensual -> high = top-down
   "Japan":8,"Sweden":12,"the Netherlands":15,"Denmark":18,"Germany":20,"the United Kingdom":50,
   "the United States":55,"Brazil":60,"Italy":62,"France":65,"India":72,"China":75,"Russia":80,"Nigeria":82},
 "Trusting": {  # low = task-based -> high = relationship-based
   "the United States":5,"the Netherlands":12,"Denmark":14,"Germany":16,"Australia":18,"the United Kingdom":20,
   "Poland":35,"France":45,"Italy":52,"Spain":55,"Mexico":70,"Brazil":72,"India":75,"Japan":78,
   "Russia":80,"Saudi Arabia":82,"China":88,"Nigeria":90,"Ghana":85,"Kenya":84,
   "the United Arab Emirates":83,"Qatar":84,"Kuwait":82,"Egypt":80,"Zimbabwe":86,"Tanzania":85},
 "Disagreeing": {  # low = confrontational -> high = avoids confrontation
   "Israel":5,"France":12,"Germany":15,"the Netherlands":18,"Russia":20,"Spain":22,"Denmark":28,
   "Italy":30,"Australia":40,"the United States":45,"Brazil":48,"the United Kingdom":50,"Sweden":60,
   "India":65,"Mexico":68,"Saudi Arabia":70,"Ghana":75,"Peru":78,"Japan":85,"Indonesia":88,"Thailand":92,
   "Kenya":73,"Nigeria":72,
   "the United Arab Emirates":71,"Qatar":72,"Kuwait":70,"Egypt":68,"Zimbabwe":74,"Tanzania":75},
 "Scheduling": {  # low = linear-time -> high = flexible-time
   "Switzerland":3,"Germany":5,"Japan":8,"the Netherlands":12,"Sweden":13,"Denmark":14,"the United States":18,
   "the United Kingdom":22,"France":40,"Italy":50,"Spain":52,"Russia":58,"Brazil":60,"Mexico":62,
   "China":70,"India":75,"Saudi Arabia":78,"Kenya":80,"Nigeria":85,"Ghana":82,
   "the United Arab Emirates":76,"Qatar":77,"Kuwait":78,"Egypt":80,"Zimbabwe":83,"Tanzania":84},
}

# ----------------------------------------------------------------------------
# Scenario templates. Each dimension has 2 templates (variant A uses the first).
# behaviour_low = behaviour characteristic of the LOW pole.
# behaviour_high = behaviour characteristic of the HIGH pole.
# ----------------------------------------------------------------------------
T = {
 "Communicating":{
   "low":"state the point explicitly and spell out the details, leaving little to be inferred",
   "high":"communicate the message implicitly and rely on the listener to read between the lines",
   "tpl":[
     "In a project status meeting, a manager from {A} and a manager from {B} each explain why a deadline slipped. Is the manager from {A} more likely than the manager from {B} to {beh}?",
     "A team member from {A} and a team member from {B} each write a short brief for a new colleague. Is the one from {A} more likely than the one from {B} to {beh}?"]},
 "Evaluating":{
   "low":"give the negative parts of the feedback bluntly and directly",
   "high":"soften or wrap the criticism so the negative parts are implied rather than stated",
   "tpl":[
     "During a performance review, a supervisor from {A} and a supervisor from {B} each address an underperforming report. Is the supervisor from {A} more likely than the supervisor from {B} to {beh}?",
     "Reviewing a colleague's draft, a reviewer from {A} and a reviewer from {B} each point out serious problems. Is the reviewer from {A} more likely than the reviewer from {B} to {beh}?"]},
 "Persuading":{
   "low":"open with the recommendation first and then provide the supporting evidence",
   "high":"build the underlying reasoning and theory first and state the conclusion only at the end",
   "tpl":[
     "Pitching a proposal to leadership, a presenter from {A} and a presenter from {B} each structure their argument. Is the presenter from {A} more likely than the presenter from {B} to {beh}?",
     "Explaining a new method to a client, a consultant from {A} and a consultant from {B} each organise their explanation. Is the consultant from {A} more likely than the consultant from {B} to {beh}?"]},
 "Leading":{
   "low":"skip levels and speak directly to a senior leader without going through their immediate boss",
   "high":"respect the hierarchy and route the matter through the proper chain of command",
   "tpl":[
     "Needing a quick answer from a senior executive, an employee from {A} and an employee from {B} each decide how to reach them. Is the employee from {A} more likely than the employee from {B} to {beh}?",
     "In a meeting led by a senior director, a junior staffer from {A} and a junior staffer from {B} each handle a point they want raised. Is the one from {A} more likely than the one from {B} to {beh}?"]},
 "Deciding":{
   "low":"seek broad group consensus before the decision is treated as final",
   "high":"let the boss make the call quickly and announce it as the decision",
   "tpl":[
     "Choosing a new vendor, a team led from {A} and a team led from {B} each run the decision. Is the team from {A} more likely than the team from {B} to {beh}?",
     "Setting next quarter's strategy, a department in {A} and a department in {B} each reach their decision. Is the department in {A} more likely than the department in {B} to {beh}?"]},
 "Trusting":{
   "low":"build trust mainly through demonstrated competence and reliable delivery",
   "high":"build trust mainly through personal rapport and time spent socialising",
   "tpl":[
     "Starting a new partnership, a lead from {A} and a lead from {B} each work on earning the other side's trust. Is the lead from {A} more likely than the lead from {B} to {beh}?",
     "Onboarding a key supplier, a manager from {A} and a manager from {B} each approach the relationship. Is the manager from {A} more likely than the manager from {B} to {beh}?"]},
 "Disagreeing":{
   "low":"voice the disagreement openly and debate it in front of the whole group",
   "high":"avoid open confrontation and raise the concern privately or indirectly",
   "tpl":[
     "In a design review, a member from {A} and a member from {B} each disagree with the lead's proposal. Is the member from {A} more likely than the member from {B} to {beh}?",
     "When a manager announces an unpopular decision, an employee from {A} and an employee from {B} each respond. Is the employee from {A} more likely than the employee from {B} to {beh}?"]},
 "Scheduling":{
   "low":"treat the schedule as fixed and expect meetings to start and finish exactly on time",
   "high":"treat the schedule as flexible and adjust timings freely as the day unfolds",
   "tpl":[
     "Running a multi-step project, a coordinator from {A} and a coordinator from {B} each manage the timeline. Is the coordinator from {A} more likely than the coordinator from {B} to {beh}?",
     "Hosting a full day of back-to-back meetings, an organiser from {A} and an organiser from {B} each handle the timing. Is the organiser from {A} more likely than the organiser from {B} to {beh}?"]},
}

INSTRUCTION = " Answer only Yes or No."

def valid_pairs(dim):
    """All country pairs on a dimension separated by >= MIN_SEP.

    Counter-stereotype = two countries in the SAME macro region on OPPOSITE
    sides of the midpoint (the naive 'same region behaves alike' heuristic
    fails). Expansion countries are forced to be NON-counter and are only
    emitted in clear cross-region, opposite-pole comparisons (extreme vs the
    opposite extreme), so an imputed bloc position is never the hinge of a
    nuanced item."""
    pos = SCALES[dim]
    out = []
    for a, b in itertools.combinations(pos.keys(), 2):
        sep = abs(pos[a]-pos[b])
        if sep < MIN_SEP:
            continue
        opposite_poles = (pos[a]-MID)*(pos[b]-MID) < 0
        same_macro = macro(a) == macro(b)
        is_exp = (a in EXPANSION) or (b in EXPANSION)
        if is_exp:
            # expansion country only as an extreme vs an opposite extreme in a
            # DIFFERENT macro region -> always a clean, stereotype-consistent item
            if (not opposite_poles) or same_macro:
                continue
            counter = False
        else:
            counter = same_macro and opposite_poles
        out.append({"a":a,"b":b,"sep":sep,"counter":counter,"expansion":is_exp})
    return out

def build_item(dim, tpl_idx, pair, item_id, group_id):
    pos = SCALES[dim]
    a, b = pair["a"], pair["b"]
    # randomise display order
    if random.random() < 0.5:
        a, b = b, a
    # randomise which pole the question asks about (balances Yes/No)
    pole = random.choice(["low","high"])
    beh = T[dim][pole]
    question = T[dim]["tpl"][tpl_idx].format(A=a, B=b, beh=beh)
    # gold: "Yes" if A shows the asked behaviour more than B
    if pole == "low":
        gold = "Yes" if pos[a] < pos[b] else "No"
    else:
        gold = "Yes" if pos[a] > pos[b] else "No"
    return {
        "id": item_id,
        "block": "B1",
        "dimension": dim,
        "template_id": f"{dim[:4].upper()}-T{tpl_idx+1}",
        "pair_group": group_id,
        "scenario": question + INSTRUCTION,
        "country_a": a, "country_b": b,
        "cluster_a": CLUSTER[a], "cluster_b": CLUSTER[b],
        "gold_answer": gold,
        "is_counter_stereotype": pair["counter"],
        "uses_expansion": pair.get("expansion", False),
        "separation": pair["sep"],
        "pole_asked": pole,
    }

def per_dim_counts(total, ndim=8):
    base = total // ndim
    rem = total - base*ndim
    return [base+1 if i < rem else base for i in range(ndim)]

def select_pairs(pool, k, cluster_load, country_load, n_counter_target, used):
    """Greedy pick k pairs: hit a counter-stereotype quota, balance clusters AND
    spread individual countries, prefer larger separation, avoid country pairs
    already in `used`."""
    chosen = []
    n_counter_target = min(n_counter_target, sum(1 for p in pool if p["counter"]))
    def score(p):
        # lower is better: under-loaded clusters, under-used countries, wider sep
        return (cluster_load[CLUSTER[p["a"]]] + cluster_load[CLUSTER[p["b"]]]
                + 0.5*(country_load[p["a"]] + country_load[p["b"]])
                - p["sep"]/100.0)
    counters_taken = 0
    remaining = [p for p in pool]
    while len(chosen) < k and remaining:
        need_counter = counters_taken < n_counter_target
        # eligible candidates (no duplicate country pair), constrained to the
        # right type while the quota for that type is still open
        cands = [p for p in remaining if frozenset((p["a"],p["b"])) not in used]
        if not cands: break
        slots_left = k - len(chosen)
        counters_left_needed = n_counter_target - counters_taken
        if need_counter:
            pref = [p for p in cands if p["counter"]] or cands
        elif (slots_left - counters_left_needed) <= 0:
            pref = [p for p in cands if p["counter"]] or cands
        else:
            pref = [p for p in cands if not p["counter"]] or cands
        pick = min(pref, key=score)
        used.add(frozenset((pick["a"],pick["b"])))
        cluster_load[CLUSTER[pick["a"]]] += 1
        cluster_load[CLUSTER[pick["b"]]] += 1
        country_load[pick["a"]] += 1
        country_load[pick["b"]] += 1
        if pick["counter"]: counters_taken += 1
        chosen.append(pick)
        remaining.remove(pick)
    return chosen

def generate(n_templates):
    dims = list(SCALES.keys())
    counts = per_dim_counts(TOTAL, len(dims))
    cluster_load = defaultdict(int)
    country_load = defaultdict(int)
    items = []

    # Pass 1: enumerate all (dim, template, size) splits and their counter pools
    splits = []
    for di, dim in enumerate(dims):
        pool = valid_pairs(dim)
        avail_counter = sum(1 for p in pool if p["counter"])
        k = counts[di]
        if n_templates == 1:
            parts = [(0, k)]
        else:
            k1 = (k+1)//2; k2 = k - k1
            parts = [(0, k1), (1, k2)]
        for tpl_idx, kk in parts:
            splits.append({"dim":dim,"tpl":tpl_idx,"kk":kk,"pool":pool,
                           "cap":min(kk, avail_counter)})

    # Pass 2: distribute the global counter quota (largest-remainder), capped per split
    quota = round(TOTAL * COUNTER_TARGET)
    raw = [s["kk"]*COUNTER_TARGET for s in splits]
    base = [min(int(r), splits[i]["cap"]) for i,r in enumerate(raw)]
    assigned = sum(base)
    rema = sorted(range(len(splits)), key=lambda i: raw[i]-int(raw[i]), reverse=True)
    j = 0
    while assigned < quota and j < len(rema)*4:
        i = rema[j % len(rema)]
        if base[i] < splits[i]["cap"]:
            base[i] += 1; assigned += 1
        j += 1
    for i,s in enumerate(splits): s["ctgt"] = base[i]

    # Pass 3: select pairs (used-set shared per dimension so the two templates
    # of a dimension draw DISTINCT country pairs -> wider coverage)
    gid = 0
    used_by_dim = defaultdict(set)
    for s in splits:
        picks = select_pairs([dict(p) for p in s["pool"]], s["kk"], cluster_load,
                              country_load, s["ctgt"], used_by_dim[s["dim"]])
        gid += 1
        for p in picks:
            it = build_item(s["dim"], s["tpl"], p, f"B1-{len(items)+1:03d}", f"G{gid:02d}")
            items.append(it)
    return items

def report(items, name):
    n = len(items)
    yes = sum(1 for i in items if i["gold_answer"]=="Yes")
    ctr = sum(1 for i in items if i["is_counter_stereotype"])
    cl = defaultdict(int)
    for i in items:
        cl[i["cluster_a"]] += 1; cl[i["cluster_b"]] += 1
    print(f"\n=== {name}: {n} items ===")
    print(f"Yes/No: {yes}/{n-yes}  ({yes/n:.0%} Yes)")
    print(f"Counter-stereotype: {ctr}/{n} ({ctr/n:.0%})")
    print(f"Min separation: {min(i['separation'] for i in items)}")
    print("Cluster slots (target ~%.1f each):" % (2*n/10))
    for c in sorted(cl): print(f"   {c:22s} {cl[c]}")
    per_dim = defaultdict(int)
    for i in items: per_dim[i["dimension"]] += 1
    print("Per dimension:", dict(per_dim))

for variant, ntpl in [("A_1template", 1), ("B_2templates", 2)]:
    random.seed(42)
    items = generate(ntpl)
    report(items, variant)
    path = f"/home/claude/B1_factual_{variant}.jsonl"
    with open(path, "w") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")
    print("written:", path)
