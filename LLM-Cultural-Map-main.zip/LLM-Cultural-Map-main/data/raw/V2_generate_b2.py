#!/usr/bin/env python3
"""
B2 (Applied) generator — LLM Cultural Map benchmark.

Design (parallel to B1 V2 rebuild):
- Each item describes a cross-cultural workplace misunderstanding involving
  TWO named countries and asks a 4-option MCQ. The correct answer is always
  the culturally-grounded interpretation; distractors are plausible
  non-cultural explanations (administrative, interpersonal, technical).
- SAME SCENARIO TEMPLATE across MULTIPLE COUNTRY PAIRS (the pair_group
  mechanic from B1): the situation is word-for-word identical; only the
  country names change. Consistency within a pair_group is the headline
  metric — a model that truly grasps the dimension answers correctly across
  famous AND obscure pairs.
- ~35% COUNTER-STEREOTYPE items: the two countries come from the SAME
  macro-region but sit on OPPOSITE sides of the dimension. The naive
  "same-region → same-behaviour" shortcut fails on these.
- ANSWER ROTATION: the correct answer is randomly assigned to A/B/C/D
  across items (target ≈ 25% each); distractors are shuffled accordingly.
  This prevents a fixed-position bias.
- Expansion countries (UAE, Qatar, Kuwait, Egypt, Zimbabwe, Tanzania) used
  only in clear cross-region, stereotype-CONSISTENT pairs. They NEVER
  appear in counter-stereotype items.
- Two variants:
    VARIANT A — 1 template per dimension, 12 pairs each, 8 pair_groups.
    VARIANT B — 2 templates per dimension, ~6 pairs each, 16 pair_groups.

Schema fields:
  id, block, dimension, template_id, pair_group,
  scenario, question, options (dict A-D), correct,
  country_low, country_high,   ← which country exhibits the LOW-pole /
  cluster_low, cluster_high,      HIGH-pole behaviour in the scenario
  gold_pole,                   ← which pole (low/high) the scenario depicts
  is_counter_stereotype, uses_expansion, separation, weight
"""

import json, random, itertools
from collections import defaultdict

random.seed(42)
MIN_SEP      = 25
MID          = 50
TOTAL        = 96      # 12 per dimension
COUNTER_TARGET = 0.35
WEIGHT       = 2

# ── GLOBE clusters ────────────────────────────────────────────────────────────
CLUSTER = {
    "the United States":"Anglo","the United Kingdom":"Anglo",
    "Australia":"Anglo","Canada":"Anglo",
    "Germany":"Germanic Europe","the Netherlands":"Germanic Europe",
    "Switzerland":"Germanic Europe","Austria":"Germanic Europe",
    "Denmark":"Nordic Europe","Sweden":"Nordic Europe",
    "Norway":"Nordic Europe","Finland":"Nordic Europe",
    "France":"Latin Europe","Italy":"Latin Europe",
    "Spain":"Latin Europe","Israel":"Latin Europe",
    "Russia":"Eastern Europe","Poland":"Eastern Europe",
    "Brazil":"Latin America","Mexico":"Latin America",
    "Argentina":"Latin America","Peru":"Latin America",
    "Saudi Arabia":"Middle East","Iran":"Southern Asia",
    "Nigeria":"Sub-Saharan Africa","Ghana":"Sub-Saharan Africa",
    "Kenya":"Sub-Saharan Africa",
    "India":"Southern Asia","Indonesia":"Southern Asia",
    "Thailand":"Southern Asia","the Philippines":"Southern Asia",
    "China":"Confucian Asia","Japan":"Confucian Asia",
    "South Korea":"Confucian Asia","Singapore":"Confucian Asia",
    # expansion
    "the United Arab Emirates":"Middle East","Qatar":"Middle East",
    "Kuwait":"Middle East","Egypt":"Middle East",
    "Zimbabwe":"Sub-Saharan Africa","Tanzania":"Sub-Saharan Africa",
    # additional countries used in SCALES
    "Turkey":"Middle East",
    "Hungary":"Eastern Europe","Czech Republic":"Eastern Europe",
    "Colombia":"Latin America","Venezuela":"Latin America",
    "South Africa":"Sub-Saharan Africa",
    "Morocco":"Middle East",
    "Portugal":"Latin Europe","Greece":"Latin Europe",
    "Lebanon":"Middle East","Pakistan":"Southern Asia",
}

EXPANSION = {
    "the United Arab Emirates","Qatar","Kuwait","Egypt",
    "Zimbabwe","Tanzania",
}

def macro(c):
    cl = CLUSTER[c]
    if cl in ("Anglo","Germanic Europe","Nordic Europe",
               "Latin Europe","Eastern Europe"):  return "WEST"
    if cl in ("Confucian Asia","Southern Asia"):   return "ASIA"
    if cl == "Latin America":                       return "LATAM"
    if cl == "Sub-Saharan Africa":                  return "AFRICA"
    if cl == "Middle East":                         return "MENA"

# ── Meyer scales (0 = far LOW pole, 100 = far HIGH pole) ─────────────────────
SCALES = {
 "Communicating": {
   "the United States":5,"Australia":8,"Canada":12,"the Netherlands":15,
   "Germany":18,"Denmark":20,"the United Kingdom":28,"Poland":35,
   "Italy":50,"Spain":52,"Argentina":57,"Brazil":55,"France":58,
   "Mexico":60,"India":70,"Singapore":72,"Kenya":73,
   "Saudi Arabia":80,"Iran":82,"China":85,"South Korea":88,
   "Indonesia":90,"Japan":95,"Ghana":72,"Nigeria":76,
   "the United Arab Emirates":80,"Qatar":81,"Kuwait":79,
   "Egypt":77,"Zimbabwe":74,"Tanzania":75,
   "the Philippines":78,"Thailand":80,"Finland":22,"Sweden":23,
   "Norway":24,"Russia":45,"Austria":17,"Switzerland":16,
   "Israel":30,"Turkey":72,"Hungary":40,"Morocco":79,
 },
 "Evaluating": {
   "the Netherlands":5,"Germany":8,"Denmark":10,"Russia":12,
   "Israel":14,"France":25,"Spain":35,"Italy":40,
   "Australia":45,"the United States":50,"Canada":55,
   "the United Kingdom":58,"Brazil":60,"Argentina":62,
   "Mexico":68,"India":72,"Saudi Arabia":75,"Kenya":78,
   "Ghana":80,"China":85,"Indonesia":88,"Japan":92,
   "Thailand":95,"Nigeria":79,
   "the United Arab Emirates":76,"Qatar":75,"Kuwait":76,
   "Egypt":73,"Zimbabwe":79,"Tanzania":80,
   "the Philippines":82,"South Korea":87,"Finland":12,
   "Sweden":15,"Norway":13,"Austria":9,"Switzerland":7,
   "Poland":18,"Turkey":65,"Hungary":30,"Morocco":70,
   "Colombia":65,"Czech Republic":20,"Portugal":55,
 },
 "Persuading": {
   "the United States":5,"Canada":12,"Australia":15,
   "the United Kingdom":25,"the Netherlands":35,"Denmark":40,
   "Sweden":42,"Norway":43,"Germany":70,"Spain":75,
   "France":78,"Italy":80,"Russia":85,
   "Brazil":60,"Argentina":58,"Mexico":62,
   "India":72,"Poland":55,"Israel":30,"Finland":38,
   "Turkey":68,"Hungary":60,"Kenya":65,"Nigeria":62,
   "Egypt":70,"South Korea":80,"China":78,
   "Venezuela":60,"South Africa":45,"Colombia":62,
 },
 "Leading": {
   "Denmark":5,"Sweden":8,"Norway":10,"Finland":11,
   "the Netherlands":12,"Israel":14,"Australia":18,
   "Canada":22,"the United States":25,"the United Kingdom":30,
   "Germany":35,"France":55,"Spain":56,"Italy":58,
   "Brazil":60,"Mexico":65,"India":70,"Russia":72,
   "Saudi Arabia":78,"China":80,"Nigeria":82,
   "Indonesia":84,"South Korea":88,"Japan":90,
   "Ghana":78,"Kenya":76,
   "the United Arab Emirates":80,"Qatar":81,"Kuwait":78,
   "Egypt":76,"Zimbabwe":80,"Tanzania":79,
   "the Philippines":80,"Thailand":75,"Turkey":74,
   "Poland":65,"Argentina":62,"Colombia":68,
 },
 "Deciding": {
   "Japan":8,"Sweden":12,"the Netherlands":15,"Denmark":18,
   "Germany":20,"the United Kingdom":50,"the United States":55,
   "Brazil":60,"Italy":62,"France":65,"India":72,
   "China":75,"Russia":80,"Nigeria":82,
   "Finland":14,"Norway":13,"Canada":52,"Australia":50,
   "Spain":60,"Mexico":68,"Argentina":65,"Colombia":70,
   "South Korea":78,"Indonesia":75,"Thailand":72,
   "Saudi Arabia":80,"Kuwait":78,
   "Kenya":60,"Sweden":12,
 },
 "Trusting": {
   "the United States":5,"the Netherlands":12,"Denmark":14,
   "Germany":16,"Australia":18,"the United Kingdom":20,
   "Poland":35,"France":45,"Italy":52,"Spain":55,
   "Mexico":70,"Brazil":72,"India":75,"Japan":78,
   "Russia":80,"Saudi Arabia":82,"China":88,
   "Nigeria":90,"Ghana":85,"Kenya":84,
   "the United Arab Emirates":83,"Qatar":84,"Kuwait":82,
   "Egypt":80,"Zimbabwe":86,"Tanzania":85,
   "the Philippines":82,"Thailand":76,"Turkey":75,
   "Argentina":68,"Colombia":72,
   "Switzerland":8,"Finland":16,"Sweden":14,
   "Canada":18,"Israel":30,
 },
 "Disagreeing": {
   "Israel":5,"France":12,"Germany":15,"the Netherlands":18,
   "Russia":20,"Spain":22,"Denmark":28,"Italy":30,
   "Australia":40,"the United States":45,"Brazil":48,
   "the United Kingdom":50,"Sweden":60,"India":65,
   "Mexico":68,"Saudi Arabia":70,"Ghana":75,"Peru":78,
   "Japan":85,"Indonesia":88,"Thailand":92,
   "Kenya":73,"Nigeria":72,
   "the United Arab Emirates":71,"Qatar":72,"Kuwait":70,
   "Egypt":68,"Zimbabwe":74,"Tanzania":75,
   "the Philippines":80,"South Korea":82,
   "Norway":30,"Finland":32,"Austria":16,
   "Colombia":55,"Turkey":58,
 },
 "Scheduling": {
   "Switzerland":3,"Germany":5,"Japan":8,"the Netherlands":12,
   "Sweden":13,"Denmark":14,"the United States":18,
   "the United Kingdom":22,"France":40,"Italy":50,"Spain":52,
   "Russia":58,"Brazil":60,"Mexico":62,"China":70,
   "India":75,"Saudi Arabia":78,"Kenya":80,"Nigeria":85,
   "Ghana":82,
   "the United Arab Emirates":76,"Qatar":77,"Kuwait":78,
   "Egypt":80,"Zimbabwe":83,"Tanzania":84,
   "the Philippines":76,"Thailand":73,"Turkey":70,
   "Argentina":65,"Colombia":68,"Pakistan":75,
   "Finland":15,"Norway":16,"Australia":20,
   "Canada":22,"Poland":40,"Austria":7,
   "Greece":55,"Lebanon":78,
 },
}

# ── Scenario templates ────────────────────────────────────────────────────────
# Each template defines:
#   situation_low  : one side exhibits LOW-pole behaviour
#   situation_high : one side exhibits HIGH-pole behaviour
#   tpl            : list of 2 template strings, {LOW} = low-pole country,
#                    {HIGH} = high-pole country
#   question       : list of 2 question strings (parallel to tpl)
#   correct_answer : the culturally-grounded explanation (always becomes the
#                    correct option after shuffling)
#   distractors    : 3 plausible non-cultural explanations
# ─────────────────────────────────────────────────────────────────────────────
T = {
 "Communicating": {
  "correct_answer": [
   "The high-context communicator embedded the key information in surrounding context rather than stating it directly, while the low-context communicator expected explicit delivery.",
   "The low-context speaker interpreted silence and indirect phrasing as agreement or compliance; the high-context speaker used implication rather than direct statement.",
  ],
  "distractors": [
   ["The high-context party lacked decision authority and therefore delayed a direct response.",
    "An unresolved contractual clause prevented either side from proceeding.",
    "The low-context party failed to provide adequate written documentation."],
   ["The high-context party deliberately avoided the topic to gain negotiating leverage.",
    "Both parties misunderstood the technical requirements of the project.",
    "The discrepancy arose from a translation error rather than a communication style difference."],
  ],
  "tpl": [
   "{LOW} emails {HIGH}: '{msg_low}' {HIGH} replies with a lengthy message covering context, relationships, and background before briefly addressing the task. {LOW} concludes the reply missed the point.",
   "In a meeting, {LOW} asks {HIGH} directly whether the project will be delivered on time. {HIGH} responds, '{indirect}' {LOW} records this as a confirmed commitment. The deadline passes without delivery.",
  ],
  "question": [
   "Which interpretation best explains both the structure of the reply and {LOW}'s misreading of it?",
   "Which explanation best accounts for the misunderstanding over the deadline?",
  ],
  "msg_low":  ["Project update: attached. Confirm receipt by Friday.",
               "Report needed Tuesday. Please confirm.",
               "Feedback required on proposal by end of week."],
  "indirect": ["We will do our best given the current situation.",
               "Things are progressing; there may be some adjustments needed.",
               "The team is working on it and we hope to have something soon."],
 },

 "Evaluating": {
  "correct_answer": [
   "The disagreement stems from different norms about how critical feedback should be framed and delivered, not from the substance of the assessment itself.",
   "Public criticism may have been experienced as damaging to professional dignity, regardless of the developmental intent behind it.",
  ],
  "distractors": [
   ["The recipient disagreed with the technical accuracy of the feedback and chose to disengage.",
    "The feedback was delivered through an inappropriate channel for this type of organization.",
    "The recipient was already planning to leave the project before the feedback was given."],
   ["The manager violated a universal professional norm against delivering criticism in group settings.",
    "The recipient misunderstood the technical content and responded to the wrong issue.",
    "The change in behavior reflects an unrelated personal situation rather than a response to feedback."],
  ],
  "tpl": [
   "A manager from {LOW} delivers detailed written criticism to a colleague from {HIGH}, listing specific failures before any strengths. {HIGH}'s colleague describes the document as unnecessarily harsh, despite agreeing with most of the analysis.",
   "During a team meeting, a supervisor from {LOW} addresses a report from {HIGH}: '{critique}' {HIGH}'s report becomes noticeably less engaged in subsequent discussions.",
  ],
  "question": [
   "What best explains the reaction to the feedback?",
   "What most plausibly explains the change in engagement?",
  ],
  "critique": ["This analysis misses the main point. Please redo it before Friday.",
               "There are three major weaknesses here. We need to fix them.",
               "This section is weak and needs a complete rewrite."],
 },

 "Persuading": {
  "correct_answer": [
   "The two parties prefer different sequences for presenting reasoning: one leads with the conclusion, the other builds the context before revealing it.",
   "The persuasive approach assumed a presentation logic that the audience did not share, causing the substantive content to be received less favorably than expected.",
  ],
  "distractors": [
   ["The audience disagreed with the technical assumptions behind the recommendation.",
    "The presenter's style was too informal for an executive audience.",
    "The proposal was already incompatible with the organization's existing strategy."],
   ["The financial projections were insufficiently detailed to support the argument.",
    "The presentation was too long to hold the audience's attention effectively.",
    "The audience had already made a prior commitment that the presenter was unaware of."],
  ],
  "tpl": [
   "A consultant from {LOW} opens a proposal with the recommendation on the second slide and immediately addresses implementation. Executives from {HIGH} listen politely but reject the proposal without detailed feedback.",
   "A presenter from {HIGH} spends the first half of the session on historical context, stakeholder relationships, and systems analysis before reaching the recommendation. Counterparts from {LOW} repeatedly ask to hear the conclusion first.",
  ],
  "question": [
   "Which explanation best fits the outcome?",
   "What most likely explains the gap in communication?",
  ],
 },

 "Leading": {
  "correct_answer": [
   "The egalitarian leadership style removed authority signals that employees in the hierarchical context relied upon to calibrate their own behavior.",
   "Behaviors intended to empower employees were interpreted as an absence of clear direction, because the audience expected visible authority markers to guide action.",
  ],
  "distractors": [
   ["The team lacked sufficient technical skills to operate autonomously.",
    "The manager communicated expectations inconsistently over time.",
    "The employees disagreed with the organization's strategic direction."],
   ["The manager lacked industry expertise and therefore credibility.",
    "The organization failed to define reporting responsibilities clearly.",
    "The employees were resisting change for reasons unrelated to leadership style."],
  ],
  "tpl": [
   "A manager from {LOW} encourages a team in {HIGH} to address her by first name, challenge decisions openly, and act independently. Months later, initiative is low and employees wait for explicit guidance on routine tasks.",
   "A leader from {LOW} takes over a unit in {HIGH} and replaces visible hierarchy markers with flat structures and peer-based decision-making. Employees continue routing decisions through senior leaders before acting.",
  ],
  "question": [
   "What is the most plausible explanation for the outcome?",
   "What most plausibly explains why employees did not adopt the new structure?",
  ],
 },

 "Deciding": {
  "correct_answer": [
   "The two sides attach different meanings to what a formal decision represents: one treats it as the conclusion of a rigorous process, the other as a flexible starting point.",
   "The groups differ on how much alignment should be established before a decision is treated as final and implementation can begin.",
  ],
  "distractors": [
   ["The decision lacks sufficient supporting data to move forward.",
    "External market conditions have changed enough to justify reopening the discussion.",
    "One side fears admitting earlier mistakes if the decision is revised."],
   ["The additional consultation is required by internal governance procedures.",
    "The parties disagree about implementation priorities rather than the decision itself.",
    "The delay reflects a lack of operational discipline rather than a cultural difference."],
  ],
  "tpl": [
   "After approving an initiative in a formal meeting, colleagues from {HIGH} resist revisiting it despite new information. Counterparts from {LOW} argue that decisions should remain open to revision as circumstances evolve.",
   "A team from {LOW} expects implementation to begin once the formal meeting concludes. Colleagues from {HIGH} continue holding additional discussions with affected stakeholders before committing to action.",
  ],
  "question": [
   "Which explanation best fits the tension between the two sides?",
   "What is the most likely explanation for the delay in execution?",
  ],
 },

 "Trusting": {
  "correct_answer": [
   "One side may be building trust primarily through demonstrated competence and formal process, while the other requires personal rapport and relationship investment before committing.",
   "The process established formal reliability but omitted the social bonding and personal engagement that the other side treats as a precondition for serious commitment.",
  ],
  "distractors": [
   ["One side lacks confidence in the financial viability of the proposal.",
    "The agreement requires additional legal review before either party can proceed.",
    "One side received a better offer from a competitor during the same period."],
   ["The digital process was inappropriate because online methods are rarely suitable for serious partnerships.",
    "The slower side already had a prior commitment that excluded the other.",
    "The mismatch arose from insufficient technical documentation rather than relational differences."],
  ],
  "tpl": [
   "A manager from {LOW} focuses immediately on specifications, pricing, and contract terms. A counterpart from {HIGH} repeatedly steers conversations toward personal background, shared history, and long-term relationship development. Several meetings later, {HIGH} appears reluctant to finalize.",
   "A firm from {LOW} onboards a partner from {HIGH} through an efficient digital portal: forms, compliance checks, and a short video call. {HIGH}'s partner responds slowly afterward. A competitor from a third country that invested a full day in face-to-face meetings wins the next contract.",
  ],
  "question": [
   "Which explanation best accounts for the reluctance to finalize?",
   "What element was most likely missing from the approach by the firm from {LOW}?",
  ],
 },

 "Disagreeing": {
  "correct_answer": [
   "The direct challenger intended open debate as intellectual engagement; the recipient experienced public criticism as a threat to professional standing.",
   "Silence or indirect behavior was incorrectly interpreted as agreement; the actual concerns were communicated through channels that the other side did not recognize.",
  ],
  "distractors": [
   ["The recipient is unusually sensitive relative to any cross-cultural professional standard.",
    "Public meetings are universally inappropriate venues for challenging proposals.",
    "The challenger must have used personally hostile language beyond normal directness."],
   ["The team lacked confidence in the manager to handle criticism constructively.",
    "The concerns were genuinely absent and the indirect behavior was coincidental.",
    "The discrepancy arose from a procedural misunderstanding rather than communication style."],
  ],
  "tpl": [
   "A professional from {LOW} challenges a colleague from {HIGH}'s proposal in a team meeting, listing logical flaws and inviting the group to improve the idea. {HIGH}'s colleague responds politely but withdraws from subsequent discussions.",
   "A manager from {LOW} asks whether anyone disagrees with a plan. Colleagues from {LOW} raise concerns openly; colleagues from {HIGH} stay silent. During implementation, the {HIGH} side adapts the process in ways that address concerns never mentioned in the meeting.",
  ],
  "question": [
   "What is the most accurate interpretation of the interaction?",
   "What most likely explains the gap between the meeting behavior and the implementation behavior of {HIGH}?",
  ],
 },

 "Scheduling": {
  "correct_answer": [
   "The two sides operate under different assumptions about whether schedules are fixed commitments or adaptable frameworks, leading one side to experience normal flexibility as unreliability.",
   "Activities perceived as schedule disruptions by one side are being treated by the other side as legitimate and necessary components of relationship-building or stakeholder management.",
  ],
  "distractors": [
   ["One side is deliberately causing delays to gain negotiating leverage.",
    "The project plan was unrealistic by any international standard.",
    "The delays indicate a lack of operational discipline rather than a planning philosophy difference."],
   ["The other party had an unrelated scheduling conflict that drove the behavior.",
    "Both sides misunderstood the scope of the original project agreement.",
    "The adjustment reflects a technical constraint rather than a cultural attitude toward time."],
  ],
  "tpl": [
   "A coordinator from {LOW} establishes fixed milestones for a project with {HIGH}. {HIGH}'s team consistently adjusts timings to accommodate emerging stakeholder priorities. Overall quality remains high but deadlines slip. {LOW} considers introducing contractual penalties.",
   "A manager from {LOW} visits {HIGH} with back-to-back meetings scheduled. Hosts extend discussions, introduce relationship-building conversations, and propose additional social engagements. {LOW}'s manager becomes concerned about unfinished items.",
  ],
  "question": [
   "Which interpretation best explains the recurring pattern?",
   "Which interpretation most accurately explains the situation?",
  ],
 },
}

# ── Pair-validity logic (identical to B1) ────────────────────────────────────
def valid_pairs(dim):
    pos = SCALES[dim]
    out = []
    for a, b in itertools.combinations(pos.keys(), 2):
        sep = abs(pos[a] - pos[b])
        if sep < MIN_SEP:
            continue
        # a = LOW pole, b = HIGH pole  (enforce by convention; swap later if needed)
        low_c, high_c = (a, b) if pos[a] < pos[b] else (b, a)
        opposite_poles = (pos[low_c] - MID) * (pos[high_c] - MID) < 0
        same_macro     = macro(low_c) == macro(high_c)
        is_exp         = (low_c in EXPANSION) or (high_c in EXPANSION)
        if is_exp:
            if (not opposite_poles) or same_macro:
                continue
            counter = False
        else:
            counter = same_macro and opposite_poles
        out.append({
            "low": low_c, "high": high_c,
            "sep": sep, "counter": counter, "expansion": is_exp,
        })
    return out

# ── Answer shuffling ──────────────────────────────────────────────────────────
_ANSWER_SLOTS = ["A", "B", "C", "D"]

def shuffle_options(correct_text, distractor_texts):
    """Return (options_dict, correct_key) with the correct answer placed
    randomly so the position distribution converges to 25% each."""
    slot = random.choice(_ANSWER_SLOTS)
    others = [s for s in _ANSWER_SLOTS if s != slot]
    random.shuffle(others)
    random.shuffle(distractor_texts)
    options = {}
    di = 0
    for s in _ANSWER_SLOTS:
        if s == slot:
            options[s] = correct_text
        else:
            options[s] = distractor_texts[di]; di += 1
    return options, slot

# ── Build one item ────────────────────────────────────────────────────────────
def build_item(dim, tpl_idx, pair, item_id, group_id):
    low_c  = pair["low"]
    high_c = pair["high"]

    tpl_data = T[dim]
    template = tpl_data["tpl"][tpl_idx]
    question = tpl_data["question"][tpl_idx]

    # fill optional inline variables (msg_low, indirect, critique, …)
    fill = {}
    for key in ("msg_low", "indirect", "critique"):
        if key in tpl_data:
            fill[key] = random.choice(tpl_data[key])

    scenario = template.format(LOW=low_c, HIGH=high_c, **fill)
    question = question.format(LOW=low_c, HIGH=high_c)

    correct_text   = tpl_data["correct_answer"][tpl_idx]
    distractor_set = list(tpl_data["distractors"][tpl_idx])  # copy

    options, correct_key = shuffle_options(correct_text, distractor_set)

    return {
        "id":                item_id,
        "block":             "B2",
        "dimension":         dim,
        "template_id":       f"{dim[:4].upper()}-T{tpl_idx + 1}",
        "pair_group":        group_id,
        "scenario":          scenario,
        "question":          question,
        "options":           options,
        "correct":           correct_key,
        "country_low":       low_c,
        "country_high":      high_c,
        "cluster_low":       CLUSTER[low_c],
        "cluster_high":      CLUSTER[high_c],
        "gold_pole":         "low_explicit",   # scenario always shows LOW acting first
        "is_counter_stereotype": pair["counter"],
        "uses_expansion":    pair.get("expansion", False),
        "separation":        pair["sep"],
        "weight":            WEIGHT,
    }

# ── Pair selection (greedy, from B1) ─────────────────────────────────────────
def select_pairs(pool, k, cluster_load, country_load, n_counter_target, used):
    chosen = []
    n_counter_target = min(n_counter_target,
                           sum(1 for p in pool if p["counter"]))
    def score(p):
        return (cluster_load[CLUSTER[p["low"]]] + cluster_load[CLUSTER[p["high"]]]
                + 0.5 * (country_load[p["low"]] + country_load[p["high"]])
                - p["sep"] / 100.0)
    counters_taken = 0
    remaining = list(pool)
    while len(chosen) < k and remaining:
        slots_left          = k - len(chosen)
        counters_left_needed = n_counter_target - counters_taken
        cands = [p for p in remaining
                 if frozenset((p["low"], p["high"])) not in used]
        if not cands:
            break
        if counters_taken < n_counter_target:
            pref = [p for p in cands if p["counter"]] or cands
        elif (slots_left - counters_left_needed) <= 0:
            pref = [p for p in cands if p["counter"]] or cands
        else:
            pref = [p for p in cands if not p["counter"]] or cands
        pick = min(pref, key=score)
        used.add(frozenset((pick["low"], pick["high"])))
        cluster_load[CLUSTER[pick["low"]]]  += 1
        cluster_load[CLUSTER[pick["high"]]] += 1
        country_load[pick["low"]]  += 1
        country_load[pick["high"]] += 1
        if pick["counter"]:
            counters_taken += 1
        chosen.append(pick)
        remaining.remove(pick)
    return chosen

def per_dim_counts(total, ndim=8):
    base = total // ndim
    rem  = total - base * ndim
    return [base + 1 if i < rem else base for i in range(ndim)]

# ── Main generator ────────────────────────────────────────────────────────────
def generate(n_templates):
    dims          = list(SCALES.keys())
    counts        = per_dim_counts(TOTAL, len(dims))
    cluster_load  = defaultdict(int)
    country_load  = defaultdict(int)
    items         = []

    splits = []
    for di, dim in enumerate(dims):
        pool          = valid_pairs(dim)
        avail_counter = sum(1 for p in pool if p["counter"])
        k             = counts[di]
        if n_templates == 1:
            parts = [(0, k)]
        else:
            k1 = (k + 1) // 2; k2 = k - k1
            parts = [(0, k1), (1, k2)]
        for tpl_idx, kk in parts:
            splits.append({
                "dim": dim, "tpl": tpl_idx, "kk": kk,
                "pool": pool,
                "cap": min(kk, avail_counter),
            })

    # distribute counter-stereotype quota (largest-remainder)
    quota = round(TOTAL * COUNTER_TARGET)
    raw   = [s["kk"] * COUNTER_TARGET for s in splits]
    base  = [min(int(r), splits[i]["cap"]) for i, r in enumerate(raw)]
    assigned = sum(base)
    rema  = sorted(range(len(splits)),
                   key=lambda i: raw[i] - int(raw[i]), reverse=True)
    j = 0
    while assigned < quota and j < len(rema) * 4:
        i = rema[j % len(rema)]
        if base[i] < splits[i]["cap"]:
            base[i] += 1; assigned += 1
        j += 1
    for i, s in enumerate(splits):
        s["ctgt"] = base[i]

    gid          = 0
    used_by_dim  = defaultdict(set)
    for s in splits:
        picks = select_pairs(
            [dict(p) for p in s["pool"]], s["kk"],
            cluster_load, country_load, s["ctgt"],
            used_by_dim[s["dim"]],
        )
        gid += 1
        for p in picks:
            it = build_item(
                s["dim"], s["tpl"], p,
                f"B2-{len(items) + 1:03d}", f"G{gid:02d}",
            )
            items.append(it)
    return items

# ── Report ────────────────────────────────────────────────────────────────────
def report(items, name):
    n   = len(items)
    ctr = sum(1 for i in items if i["is_counter_stereotype"])
    cl  = defaultdict(int)
    for i in items:
        cl[i["cluster_low"]]  += 1
        cl[i["cluster_high"]] += 1
    cd  = defaultdict(int)
    for i in items:
        cd[i["correct"]] += 1
    print(f"\n=== {name}: {n} items ===")
    print(f"Counter-stereotype: {ctr}/{n} ({ctr/n:.0%})")
    print(f"Min separation: {min(i['separation'] for i in items)}")
    print(f"Correct-answer distribution: {dict(sorted(cd.items()))}")
    print("Cluster slots (target ~%.1f each):" % (2 * n / 10))
    for c in sorted(cl):
        print(f"   {c:25s} {cl[c]}")
    per_dim = defaultdict(int)
    for i in items:
        per_dim[i["dimension"]] += 1
    print("Per dimension:", dict(per_dim))

# ── Run ───────────────────────────────────────────────────────────────────────
for variant, ntpl in [("A_1template", 1), ("B_2templates", 2)]:
    random.seed(42)
    items = generate(ntpl)
    report(items, variant)
    path = f"/home/claude/V2_B2_applied_{variant}.jsonl"
    with open(path, "w") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")
    print("written:", path)
