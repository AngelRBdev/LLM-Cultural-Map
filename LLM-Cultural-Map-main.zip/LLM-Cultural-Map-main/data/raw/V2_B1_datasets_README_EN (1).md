# B1 (Factual) — Dataset Documentation

Short document explaining what each of the two B1 JSONL files contains and how they were built. Both are generated with `generate_b1.py` (reproducible, `seed=42`). **96 questions each, 12 per Meyer dimension.**

---

## 1. Why B1 was rebuilt

With the previous B1 questions almost all models scored close to 100% accuracy. That does not tell us **what** we are measuring: does the model understand culture, or has it simply seen Meyer's book (and similar texts) in its training data? This is a **validity** problem, not a difficulty problem.

The redesign separates two levers:

- **Format** (yes/no, easy to parse) → improves the *reliability* of the measurement.
- **Content** (gold not from the book, varied countries, counter-stereotype items) → this is what actually distinguishes *memorization* from *understanding*.

---

## 2. Methodology shared by both files

- **Comparative yes/no items.** Each question names two countries and asks whether the person from country A is *more likely* than the person from country B to show a behaviour tied to **one** Meyer dimension.
- **The gold answer is derived from data, not hand-written.** It is computed from each country's position on Meyer's scale for that dimension. Every answer is defensible: *"Yes, because Meyer places A toward the low-context pole relative to B."*
- **Separation threshold (`MIN_SEP = 25`** on a 0–100 scale). A pair is only used if the two countries are clearly separated on that dimension, so the gold survives small ordering errors in mid-scale countries.
- **Country variation per situation (`pair_group`).** The same scenario template is instantiated with several country pairs (A vs B, C vs D, E vs F…). **Consistency within a `pair_group` is the headline metric:** a model that understands the *dimension* gets both the famous and the less-documented pairs right; a model that memorized famous examples fails on the obscure pairs.
- **35% counter-stereotype items (`is_counter_stereotype`).** Two countries from the *same macro-region* but on *opposite sides* of the dimension (the naive "same region → same behaviour" heuristic fails). E.g.: Japan (consensual) vs India (top-down); Japan (linear-time) vs China (flexible-time); France (confrontational) vs Sweden (avoids confrontation). The accuracy gap between consistent and counter-stereotype items is itself evidence of shortcut learning.
- **GLOBE balance.** Pairs are chosen to spread the 10 GLOBE clusters as evenly as the data allows, and to avoid any single country dominating.
- **Randomization.** The order of mention (A/B) and which behavioural pole the question asks about are randomized, so neither position nor a fixed "Yes" bias predicts the answer.

---

## 3. Country table and expansion

- **Gold positions** come from Meyer's canonical published scales, corroborated against the book text (the supplied Meyer file is plain text without the scale figures, so mid-scale positions especially should be cross-checked against the printed book).
- **Why 96 and not 60.** With a script, generation is essentially free, so the count is set by statistical power, not by hand-writing effort. 96 (12/dimension) gives ~4 counter-stereotype items per dimension and 7–12 pairs per `pair_group`, enough for per-dimension and consistency claims.
- **Thin-cluster problem.** Some GLOBE clusters have very few countries that Meyer places on his scales — Middle East had only **Saudi Arabia**. At 96 questions with strict balance, Saudi Arabia would have to appear ~16 times. To avoid that, the country table was expanded.
- **Key principle — placement by evidence, not by cluster identity.** Countries are NOT added as blanket cluster stand-ins. Assuming "same GLOBE cluster → same Meyer position" is **exactly the shortcut the benchmark tests**, and it is false for several clusters (e.g. Confucian Asia on *Deciding*: Japan is ultra-consensual while China is top-down; Israel sits at the egalitarian extreme, unlike the rest of Latin Europe). Imputing a position from a cluster-mate would inject wrong gold and would *reward* the regional-lumping shortcut. So each new country is placed only where the relevant bloc is genuinely homogeneous in the cross-cultural literature.
- **Expansion countries** (`uses_expansion: true`): the Arab Gulf bloc — **United Arab Emirates, Qatar, Kuwait, Egypt** (Middle East) — and **Zimbabwe, Tanzania** (Sub-Saharan Africa). These blocs sit consistently on the high-context / relationship-based / indirect-feedback / hierarchical / flexible-time ends.
- **Guardrail (enforced in code).** Expansion countries are used ONLY in clear cross-region, opposite-pole, stereotype-**consistent** comparisons (an extreme vs the opposite extreme). They **never appear in counter-stereotype items**, because that is where intra-cluster nuance matters and imputation would be unsafe. Result: Saudi Arabia now appears once instead of ~16 times, and Middle East is carried by the whole Gulf bloc.
- **Honest, imperfect balance.** Middle East is not on Meyer's *Persuading* or *Deciding* scales, so it stays under-represented on those two dimensions. *Persuading* is also structurally Western in Meyer (holistic cultures are off-scale), which tilts the overall balance slightly toward Western clusters (achieved range ≈ 15–23 slots per cluster vs a 19.2 target). This is reported honestly rather than "fixed" by fabricating non-Western positions.

---

## 4. Record schema (one JSONL line)

| Field | Description |
|---|---|
| `id` | Unique identifier (`B1-001`…). |
| `block` | Always `"B1"`. |
| `dimension` | Meyer dimension (`Communicating`, `Evaluating`, …). |
| `template_id` | Scenario template used (`COMM-T1`, `COMM-T2`…). |
| `pair_group` | Groups instances of the **same situation** with different countries. Key for the consistency analysis. |
| `scenario` | Full prompt text + `"Answer only Yes or No."` |
| `country_a` / `country_b` | The two countries compared. |
| `cluster_a` / `cluster_b` | GLOBE cluster of each country. |
| `gold_answer` | `"Yes"` or `"No"`, derived from Meyer's scales. |
| `is_counter_stereotype` | `true` if the item is a counter-stereotype trap. |
| `uses_expansion` | `true` if an expansion country is involved (always a stereotype-consistent item). |
| `separation` | Distance between the two countries on the scale (≥ 25). |
| `pole_asked` | Whether the prompt asks about the `low` or `high` pole behaviour. |

---

## 5. The two files

Both cover the 8 dimensions with 96 questions and identical parameters. The only difference is **how many scenario templates** each uses.

### `B1_factual_A_1template.jsonl`
- **1 scenario template per dimension**, instantiated across 12 country pairs.
- 8 `pair_groups` (one per dimension), each large → very clean consistency signal (the scenario is word-for-word identical within a group; only the countries change).

### `B1_factual_B_2templates.jsonl`
- **2 scenario templates per dimension**, ~6 pairs each (different countries between the two templates).
- 16 `pair_groups`, smaller → more phrasing variety; more robust against a model "catching on" to a single template; also tests phrasing sensitivity.

| Metric | Variant A | Variant B |
|---|---|---|
| Questions | 96 | 96 |
| Templates / dimension | 1 | 2 |
| `pair_groups` | 8 | 16 |
| % counter-stereotype | 35% | 35% |
| Yes/No split | 55 / 41 | 55 / 41 |
| Minimum separation | 25 | 25 |
| Slots per GLOBE cluster | 15–23 | 15–23 |
| Items using an expansion country | 19 | 19 |

---

## 6. How to decide which one becomes the final dataset

When running the 5 models, do not look only at mean accuracy. Three signals (all extractable from the JSONL flags) indicate whether culture or memory is being measured:

1. **Consistent vs counter-stereotype gap** (`is_counter_stereotype`): if accuracy collapses on the counter-stereotype items → shortcut learning.
2. **Consistency within each `pair_group`**: does the model get all pairs of the same situation right, or only the famous ones?
3. **Spread across models**: the variant that most separates the 5 models has the most discriminatory power → keep that one.

---

## 7. Notes

- **Coordination:** B1 now has 96 questions (not 60); whoever owns the scoring code should account for this in the point distribution.
- **Gold provenance.** Positions rely on Meyer's canonical scales plus cross-cultural evidence; the expansion countries are the least-documented placements and should be verified by the team. They are used only in unambiguous extreme comparisons for this reason.
- **Tunable parameters** (header of `generate_b1.py`, regenerates in seconds): `MIN_SEP` (raise to 30–35 for an even more conservative gold), `COUNTER_TARGET`, `TOTAL`, the `EXPANSION` set, and the texts in the `T` dictionary for less "templated" scenarios.
