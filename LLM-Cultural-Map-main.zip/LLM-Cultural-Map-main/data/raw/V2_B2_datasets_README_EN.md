+# B2 (Applied) — Dataset Documentation

Short document explaining what each of the two B2 JSONL files contains and how they were built. Both are generated with `V2_generate_b2.py` (reproducible, `seed=42`). **96 questions each, 12 per Meyer dimension.**

---

## 1. Why B2 was rebuilt

The original B2 had 80 questions (10 per dimension) with two structural problems:

- **Answer bias**: 64% of correct answers were option A. A model that always answers A scores 64% without reading anything — this is a reliability failure, not a difficulty signal.
- **No consistency mechanic**: each question used a unique country pair and scenario. There was no way to distinguish a model that understands the *dimension* from one that knows the specific country examples. Same validity problem as the old B1.
- **No counter-stereotype items**: the naive "same region → same behaviour" heuristic was never tested.

The redesign applies the same fixes used in B1 V2.

---

## 2. What B2 measures (and how it differs from B1)

B1 measures **knowledge** of Meyer's framework through Yes/No comparative judgements computed directly from the scales.

B2 measures **applied understanding**: given a realistic workplace misunderstanding scenario, can the model identify the culturally-grounded explanation and reject plausible non-cultural distractors?

Both use the same underlying scale positions and the same pair-selection logic. The difference is purely in question format:

| | B1 | B2 |
|---|---|---|
| Format | Yes/No comparative | 4-option MCQ |
| What is tested | Scale knowledge | Interpretation of a scenario |
| Correct answer source | Computed from Meyer positions | Fixed correct + 3 non-cultural distractors |
| Weight | 1 | 2 |

---

## 3. Methodology shared by both files

### Same-scenario / different-countries mechanic (`pair_group`)
The core anti-memorisation device, borrowed from B1. Each template describes a misunderstanding (e.g. "a low-context manager misreads a high-context reply"). The *situation* is word-for-word identical across all items in a `pair_group`; only the country names change.

A model that has memorised "Finnish vs Egyptian → high-context gap" will answer the famous pair correctly but fail on "Austrian vs Nigerian" or "Polish vs Russian". A model that genuinely understands the *Communicating* dimension answers both correctly. Per-group accuracy is therefore a cleaner signal than mean accuracy.

### Gold answer derivation
The correct answer always describes the culturally-grounded mechanism. It is the same text across all items in a `pair_group` (the countries are not named in the answer text). The three distractors are plausible non-cultural explanations: administrative, interpersonal, technical, or procedural. This means the correct answer is not inferrable from the countries alone — the model must understand which type of explanation the scenario calls for.

### Counter-stereotype items (35%)
Same definition as B1: two countries from the same macro-region (WEST / ASIA / LATAM / AFRICA / MENA) but on opposite sides of the dimension midpoint. Examples: Japan (linear-time) vs China (flexible-time) on Scheduling; Japan (consensual) vs India/Indonesia (top-down) on Deciding; Austria/France (confrontational) vs Sweden/Denmark (avoids confrontation) on Disagreeing.

### Answer position randomisation
The correct answer is randomly assigned to A, B, C, or D for each item (target ≈ 25% each). The three distractors fill the remaining slots in random order. This eliminates the position bias of the original B2 (where A was correct 64% of the time). With `seed=42` and 96 items the achieved distribution is A:25, B:21, C:31, D:19 — not perfectly uniform, but well within acceptable range and free from the systematic bias of the original.

### Separation threshold and expansion countries
Same rules as B1: `MIN_SEP = 25` on the 0–100 scale; expansion countries (UAE, Qatar, Kuwait, Egypt, Zimbabwe, Tanzania) used only in clear cross-region stereotype-consistent comparisons and never in counter-stereotype items.

---

## 4. Record schema (one JSONL line)

| Field | Description |
|---|---|
| `id` | Unique identifier (`B2-001`…). |
| `block` | Always `"B2"`. |
| `dimension` | Meyer dimension. |
| `template_id` | Scenario template used (`COMM-T1`, `COMM-T2`…). |
| `pair_group` | Groups instances of the **same situation** with different country pairs. Key for the consistency analysis. |
| `scenario` | Full situation text (country names filled in). |
| `question` | The MCQ question stem. |
| `options` | Dict with keys A–D; one is the culturally-grounded explanation, three are non-cultural distractors. |
| `correct` | The correct option key (`"A"`, `"B"`, `"C"`, or `"D"`). |
| `country_low` | The country exhibiting the LOW-pole behaviour in the scenario. |
| `country_high` | The country exhibiting the HIGH-pole behaviour in the scenario. |
| `cluster_low` / `cluster_high` | GLOBE cluster of each country. |
| `gold_pole` | Always `"low_explicit"`: the template is written so the low-pole country acts first. |
| `is_counter_stereotype` | `true` if both countries are from the same macro-region but opposite poles. |
| `uses_expansion` | `true` if an expansion country is involved. |
| `separation` | Distance between the two countries on the Meyer scale (≥ 25). |
| `weight` | Always `2` (applied items are weighted higher than factual Yes/No items). |

---

## 5. The two files

Both cover all 8 dimensions with 96 questions and identical parameters. The only difference is the number of scenario templates per dimension.

### `V2_B2_applied_A_1template.jsonl`
- **1 scenario template per dimension**, instantiated across 12 country pairs.
- 8 `pair_groups` (one per dimension), each with 12 items → very clean consistency signal (word-for-word identical situation across all 12 pairs; only country names vary).

### `V2_B2_applied_B_2templates.jsonl`
- **2 scenario templates per dimension**, ~6 pairs each.
- 16 `pair_groups`, smaller → wider phrasing variety; also tests whether the model is sensitive to how the same cultural gap is framed.

| Metric | Variant A | Variant B |
|---|---|---|
| Questions | 96 | 96 |
| Templates / dimension | 1 | 2 |
| `pair_groups` | 8 | 16 |
| % counter-stereotype | 35% | 35% |
| Correct-answer distribution | A:25, B:21, C:31, D:19 | A:25, B:21, C:31, D:19 |
| Minimum separation | 25 | 25 |
| Slots per GLOBE cluster | 18–20 | 18–20 |
| Items using an expansion country | ~19 | ~19 |
| Weight per item | 2 | 2 |

---

## 6. How to decide which variant becomes the final dataset

Same three signals as B1:

1. **Consistent vs counter-stereotype gap** (`is_counter_stereotype`): accuracy drop on counter-stereotype items → shortcut learning.
2. **Consistency within each `pair_group`**: does the model get all 12 (or 6) pairs of the same situation right, or only the famous ones?
3. **Spread across models**: the variant that most separates the 5 models has the most discriminatory power → keep that one.

If both variants produce similar model rankings, prefer **Variant B** (2 templates): its wider phrasing variety makes it a more robust test of applied understanding vs phrasing sensitivity.

---

## 7. Relationship to original B2

| Aspect | Original B2 | V2 B2 |
|---|---|---|
| Questions | 80 (10/dim) | 96 (12/dim) |
| Answer bias | 64% correct = A | ~25% each (randomised) |
| Scenario variety | Each pair unique | Same scenario, many country pairs |
| Counter-stereotype items | None | 35% |
| Consistency metric | Not applicable | Per-`pair_group` accuracy |
| IDs with gaps | Yes (`_001`, `_003`, `_REP_001`…) | Sequential `B2-001`…`B2-096` |
| Scoring weight | 2 | 2 (unchanged) |

---

## 8. Notes

- **Coordination**: B2 now has 96 questions (not 80). Whoever owns the scoring code should update the point distribution.
- **Scenario naturalness**: the templates use a fixed structure (low-context actor sends / says something; high-context actor responds implicitly; low-context actor misreads). This is intentional for the pair-group mechanic. The phrasing may sound slightly templated in Variant A. Variant B mitigates this by using a second template per dimension. If phrasing naturalness is a concern, the `tpl` list in `V2_generate_b2.py` can be extended and the script re-run in seconds.
- **Tunable parameters** (header of `V2_generate_b2.py`, regenerates in seconds): `MIN_SEP`, `COUNTER_TARGET`, `TOTAL`, the `EXPANSION` set, `WEIGHT`, and the template/answer texts in the `T` dictionary.
- **Gold provenance**: same as B1 — Meyer's canonical published scales. Expansion country placements are the least documented and should be verified by the team.
